import cv2
from ultralytics import YOLO
import pandas as pd
import gradio as gr

model = YOLO(r"C:\Users\maggi\OneDrive\Desktop\Potato Disease Detection\runs_1-20240502T070740Z-001\runs_1\detect\train2\weights\last.pt")

def detect_img(image_path):
	image = cv2.imread(image_path)
	image = cv2.resize(image, (640, 640))
	results = model(image)
	data = {}
	for result in results:
		print(result.names)
		data_dict = result.names
		example_tensor = result.boxes.cls
		count_dict = {object_name: 0 for object_name in data_dict.values()}
		for index in example_tensor:
		    item = int(index.item())  # Convert tensor value to integer
		    object_name = data_dict.get(item)
		    if object_name:
		        count_dict[object_name] += 1
		for object_name, count in count_dict.items():
	    		data[object_name] = count

	disease_list = []
	for disease, count in data.items():
	    if count > 0:
	        disease_list.append(disease)
	result_string = ', '.join(disease_list)
	if disease_list[0] == "Alternaria-Solani":
		result_string = result_string + "\n" + "Early blight, caused by the fungus Alternaria solani, is a common foliar disease affecting potato plants worldwide. It typically appears as small, dark lesions on the lower leaves, gradually expanding into irregularly shaped brown spots with concentric rings. In severe cases, these lesions can merge, leading to defoliation and reduced tuber yield. Early blight thrives in warm, humid conditions, making cultural practices such as crop rotation and proper plant spacing essential for management."

	if disease_list[0] == "Late-blight-Leaf":
		result_string = result_string + "\n" + "Late blight, caused by the oomycete pathogen Phytophthora infestans, is a devastating disease of potato plants. It appears as water-soaked lesions on the leaves, often starting at the tips or edges and rapidly expanding, turning dark brown to purplish-black in color. Under favorable conditions of high humidity and cool temperatures, the lesions can quickly engulf entire leaves, leading to rapid defoliation. Late blight not only affects foliage but can also infect potato tubers, causing significant yield losses. Timely application of fungicides and cultural practices such as crop rotation are essential for managing this destructive disease."

	if disease_list[0] == "Septoria":
		result_string = result_string + "\n" + "Septoria leaf spot, caused by the fungus Septoria lycopersici, is a prevalent foliar disease affecting potato plants. It manifests as small, circular lesions with dark borders and gray centers on the lower leaves, gradually spreading upwards as the infection progresses. In severe cases, the lesions coalesce, leading to premature defoliation and reduced tuber quality. Effective management strategies include sanitation, proper irrigation practices, and the use of resistant potato varieties where available."

	if disease_list[0] == "lancha-negra-en-tallo":
		result_string = result_string + "\n" + "'Black Scurf'  or 'lancha negra en tallo' in Spanish, is a fungal disease that affects the stems of potato plants. It manifests as dark, sunken lesions or 'black boats' on the stems, typically near the soil line or lower portions of the plant. These lesions may appear shiny or crusty and can cause weakening of the stem, leading to stunted growth and reduced yield. Black Scurf is primarily caused by the fungus Rhizoctonia solani and is favored by cool, wet soil conditions. Proper crop rotation, soil sanitation, and selecting disease-resistant potato varieties are crucial for managing this disease and minimizing its impact on potato production."

	if disease_list[0] == "Lancha-amarilla":
		result_string = result_string + "\n" + "This disease refers to the early stages of early blight and the fungus Alternaria solani"

	if disease_list[0] == "Lancha-amarilla-posterior":
		result_string = result_string + "\n" + "This disease refers to the back side of the leaf infected with early blight and the fungus Alternaria solani"

	if disease_list[0] == "Septoria-posterior":
		result_string = result_string + "\n" + "This disease refers to the back side of the leaf infected with Septoria"

	if disease_list[0] == "Síntoma-de-intoxicación":
		result_string = result_string + "\n" + "This is not a disease but detction of green tubers and sprouts that develops in potato plant, these can be harmful if consumed"

	if disease_list[0] == "lancha-negra-en-hoja":
		result_string = result_string + "\n" + '"Lancha negra en hoja" translates to "black scurf on leaves." This disease, also known as "black dot," affects potato plants and is caused by the fungus Colletotrichum coccodes. It manifests as small, dark, sunken lesions on the leaves, often resembling tiny black dots. These lesions can merge, leading to extensive damage to the foliage. Black scurf on leaves can weaken the plant, reduce photosynthesis, and ultimately impact yield. Effective management strategies include crop rotation, planting disease-free seed potatoes, and practicing good sanitation to minimize fungal spread.'

	if len(result_string) > 2:
		fnl_str = result_string
	else:
		fnl_str = "There was no disease detected from this list ['Alternaria-Solani', 'Late-blight-Leaf', 'Septoria']"

	if results:
		# print(results)
		for detection in results:
	        # Extract bounding box coordinates (x_min, y_min, x_max, y_max)
			x_min, y_min, x_max, y_max = detection.boxes.xyxy[0].tolist()  # Assuming xywh format

	        # Draw the bounding box on the image
			cv2.rectangle(image, (int(x_min), int(y_min)), (int(x_max), int(y_max)), (0, 255, 0), 2)

	        # Optionally, add a label above the bounding box (modify as needed)
			# class_id = int(detection.names[0])  # Assuming class names are in detection.names
			label = fnl_str  # Format label with class name and confidence score
			cv2.putText(image, label, (int(x_min), int(y_min) - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)

	# Display or save the image with bounding boxes
	# cv2.imshow("Image with Bounding Boxes", image)
	# cv2.waitKey(0)  # Press any key to close the window
	output_image_path = "./bound.png"
	cv2.imwrite(output_image_path, image)
	return fnl_str


def ret_str(image_path):
	# image_path = r"C:\Users\ahmad\Desktop\potato disease\Septoria-leaf.png"
	print(type(image_path))
	res = detect_img(image_path)

	processed_image = "./bound.png"
	return "Disease found: " + res, processed_image


inputs = gr.Image(type="filepath", label="Upload Image") 
# outputs = gr.Text(label="Predicted Disease") 
outputs = [gr.Textbox(label="Predicted Text"), gr.Image(label="Processed Image")] 

gr.Interface(fn=ret_str, inputs=inputs, outputs=outputs).launch()

